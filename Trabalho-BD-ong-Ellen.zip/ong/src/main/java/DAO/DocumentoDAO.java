package DAO;

import Conexao.Conexao;
import DTO.DocumentoDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DocumentoDAO {

    public boolean inserirDocumento(DocumentoDTO doc) {
        String sql = "INSERT INTO documento (nome_arquivo, caminho_arquivo, tipo_documento, id_projeto, id_usuario, data_upload) " +
                "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, doc.getNomeArquivo());
            ps.setString(2, doc.getCaminhoArquivo());
            ps.setString(3, doc.getTipoDocumento());

            if (doc.getIdProjeto() != null) {
                ps.setInt(4, doc.getIdProjeto());
            } else {
                ps.setNull(4, Types.INTEGER);
            }

            if (doc.getIdUsuario() != null) {
                ps.setInt(5, doc.getIdUsuario());
            } else {
                ps.setNull(5, Types.INTEGER);
            }

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarDocumento(DocumentoDTO doc) {
        String sql = "UPDATE documento SET nome_arquivo = ?, caminho_arquivo = ?, tipo_documento = ?, id_projeto = ?, id_usuario = ? WHERE id_documento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, doc.getNomeArquivo());
            ps.setString(2, doc.getCaminhoArquivo());
            ps.setString(3, doc.getTipoDocumento());

            if (doc.getIdProjeto() != null) {
                ps.setInt(4, doc.getIdProjeto());
            } else {
                ps.setNull(4, Types.INTEGER);
            }

            if (doc.getIdUsuario() != null) {
                ps.setInt(5, doc.getIdUsuario());
            } else {
                ps.setNull(5, Types.INTEGER);
            }

            ps.setInt(6, doc.getIdDocumento());

            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirDocumento(int idDocumento) {
        String sql = "DELETE FROM documento WHERE id_documento = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idDocumento);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<DocumentoDTO> listarDocumentos() {
        List<DocumentoDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM documento ORDER BY data_upload DESC";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                DocumentoDTO doc = new DocumentoDTO();
                doc.setIdDocumento(rs.getInt("id_documento"));
                doc.setNomeArquivo(rs.getString("nome_arquivo"));
                doc.setCaminhoArquivo(rs.getString("caminho_arquivo"));
                doc.setTipoDocumento(rs.getString("tipo_documento"));

                int idProjeto = rs.getInt("id_projeto");
                if (rs.wasNull()) doc.setIdProjeto(null);
                else doc.setIdProjeto(idProjeto);

                int idUsuario = rs.getInt("id_usuario");
                if (rs.wasNull()) doc.setIdUsuario(null);
                else doc.setIdUsuario(idUsuario);

                doc.setDataUpload(rs.getTimestamp("data_upload"));

                lista.add(doc);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}

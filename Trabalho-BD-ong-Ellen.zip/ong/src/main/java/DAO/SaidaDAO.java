package DAO;

import DTO.SaidaDTO;
import Conexao.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SaidaDAO {

    public boolean inserirSaida(SaidaDTO saida) {
        String sql = "INSERT INTO saida (id_doacao, id_doador, tipo, valor, descricao, data, projeto_id) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id_saida";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, saida.getIdDoacao());
            ps.setInt(2, saida.getIdDoador());
            ps.setString(3, saida.getTipo());
            ps.setBigDecimal(4, saida.getValor());
            ps.setString(5, saida.getDescricao());
            ps.setDate(6, saida.getData());

            if (saida.getProjetoId() != null)
                ps.setInt(7, saida.getProjetoId());
            else
                ps.setNull(7, Types.INTEGER);

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                saida.setIdSaida(rs.getInt("id_saida"));  // capturar id_saida gerado
                return true;
            }
            return false;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarSaida(SaidaDTO saida) {
        String sql = "UPDATE saida SET tipo = ?, valor = ?, descricao = ?, data = ?, projeto_id = ? " +
                     "WHERE id_saida = ? AND id_doacao = ? AND id_doador = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, saida.getTipo());
            ps.setBigDecimal(2, saida.getValor());
            ps.setString(3, saida.getDescricao());
            ps.setDate(4, saida.getData());

            if (saida.getProjetoId() != null)
                ps.setInt(5, saida.getProjetoId());
            else
                ps.setNull(5, Types.INTEGER);

            ps.setInt(6, saida.getIdSaida());
            ps.setInt(7, saida.getIdDoacao());
            ps.setInt(8, saida.getIdDoador());

            int updated = ps.executeUpdate();
            return updated > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirSaida(int idSaida, int idDoacao, int idDoador) {
        String sql = "DELETE FROM saida WHERE id_saida = ? AND id_doacao = ? AND id_doador = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idSaida);
            ps.setInt(2, idDoacao);
            ps.setInt(3, idDoador);

            int deleted = ps.executeUpdate();
            return deleted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<SaidaDTO> listarSaidas() {
        List<SaidaDTO> lista = new ArrayList<>();
        String sql = "SELECT id_saida, id_doacao, id_doador, tipo, valor, descricao, data, projeto_id FROM saida ORDER BY data DESC";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                SaidaDTO s = new SaidaDTO();
                s.setIdSaida(rs.getInt("id_saida"));
                s.setIdDoacao(rs.getInt("id_doacao"));
                s.setIdDoador(rs.getInt("id_doador"));
                s.setTipo(rs.getString("tipo"));
                s.setValor(rs.getBigDecimal("valor"));
                s.setDescricao(rs.getString("descricao"));
                s.setData(rs.getDate("data"));

                int projetoId = rs.getInt("projeto_id");
                if (rs.wasNull()) projetoId = 0;
                s.setProjetoId(projetoId == 0 ? null : projetoId);

                lista.add(s);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public SaidaDTO buscarSaidaPorId(int idSaida, int idDoacao, int idDoador) {
        SaidaDTO saida = null;
        String sql = "SELECT * FROM saida WHERE id_saida = ? AND id_doacao = ? AND id_doador = ?";

        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idSaida);
            ps.setInt(2, idDoacao);
            ps.setInt(3, idDoador);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    saida = new SaidaDTO();
                    saida.setIdSaida(rs.getInt("id_saida"));
                    saida.setIdDoacao(rs.getInt("id_doacao"));
                    saida.setIdDoador(rs.getInt("id_doador"));
                    saida.setTipo(rs.getString("tipo"));
                    saida.setValor(rs.getBigDecimal("valor"));
                    saida.setDescricao(rs.getString("descricao"));
                    saida.setData(rs.getDate("data"));

                    int projetoId = rs.getInt("projeto_id");
                    if (rs.wasNull()) projetoId = 0;
                    saida.setProjetoId(projetoId == 0 ? null : projetoId);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return saida;
    }
}

package DAO;

import Conexao.Conexao;
import DTO.FeedbackDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {

    public boolean inserirFeedback(FeedbackDTO feedback) {
        String sql = "INSERT INTO feedback (id_usuario, mensagem, data_envio) VALUES (?, ?, CURRENT_TIMESTAMP)";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, feedback.getIdUsuario());
            ps.setString(2, feedback.getMensagem());
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean excluirFeedback(int idFeedback) {
        String sql = "DELETE FROM feedback WHERE id_feedback = ?";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idFeedback);
            ps.executeUpdate();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<FeedbackDTO> listarFeedbacks() {
        List<FeedbackDTO> lista = new ArrayList<>();
        String sql = "SELECT * FROM feedback ORDER BY data_envio DESC";
        try (Connection con = Conexao.conectar();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                FeedbackDTO fb = new FeedbackDTO();
                fb.setIdFeedback(rs.getInt("id_feedback"));
                fb.setIdUsuario(rs.getInt("id_usuario"));
                fb.setMensagem(rs.getString("mensagem"));
                fb.setDataEnvio(rs.getTimestamp("data_envio"));
                lista.add(fb);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}

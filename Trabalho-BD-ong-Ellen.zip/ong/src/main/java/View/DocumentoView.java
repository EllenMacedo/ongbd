package View;

import DAO.DocumentoDAO;
import DTO.DocumentoDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class DocumentoView extends JFrame {

    private JTextField txtIdDocumento;
    private JTextField txtNomeArquivo;
    private JTextField txtCaminhoArquivo;
    private JTextField txtTipoDocumento;
    private JTextField txtIdProjeto;
    private JTextField txtIdUsuario;
    private JTextField txtDataUpload;

    private JTable tabela;
    private DefaultTableModel modelo;

    private DocumentoDAO dao;

    public DocumentoView() {
        dao = new DocumentoDAO();
        initComponents();
        listarDocumentos();
    }

    private void initComponents() {
        setTitle("Gerenciamento de Documentos");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        getContentPane().setBackground(new Color(173, 216, 230)); // azul claro
        setLayout(new BorderLayout(10, 10));

        // Painel formulário com GridBagLayout
        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 0 - ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID:"), gbc);

        txtIdDocumento = new JTextField(10);
        txtIdDocumento.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdDocumento, gbc);

        // Linha 1 - Nome Arquivo
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Nome Arquivo:"), gbc);

        txtNomeArquivo = new JTextField(25);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtNomeArquivo, gbc);

        // Linha 2 - Caminho Arquivo
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Caminho Arquivo:"), gbc);

        txtCaminhoArquivo = new JTextField(25);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtCaminhoArquivo, gbc);

        // Linha 3 - Tipo Documento
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Tipo Documento:"), gbc);

        txtTipoDocumento = new JTextField(25);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtTipoDocumento, gbc);

        // Linha 4 - ID Projeto
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Projeto:"), gbc);

        txtIdProjeto = new JTextField(10);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdProjeto, gbc);

        // Linha 5 - ID Usuário
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Usuário:"), gbc);

        txtIdUsuario = new JTextField(10);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdUsuario, gbc);

        // Linha 6 - Data Upload
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Data Upload:"), gbc);

        txtDataUpload = new JTextField(20);
        txtDataUpload.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtDataUpload, gbc);

        // Linha 7 - Botões
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnEditar = new JButton("Editar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");

        // Estilizando os botões para fundo branco, borda cinza só embaixo e letra preta
        estilizarBotaoLinhaEmbaixo(btnSalvar);
        estilizarBotaoLinhaEmbaixo(btnEditar);
        estilizarBotaoLinhaEmbaixo(btnExcluir);
        estilizarBotaoLinhaEmbaixo(btnLimpar);

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        painelFormulario.add(painelBotoes, gbc);

        // Tabela
        modelo = new DefaultTableModel(
                new Object[]{"ID", "Nome Arquivo", "Caminho", "Tipo", "ID Projeto", "ID Usuário", "Data Upload"}, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajusta larguras colunas
        tabela.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabela.getColumnModel().getColumn(1).setPreferredWidth(140);
        tabela.getColumnModel().getColumn(2).setPreferredWidth(160);
        tabela.getColumnModel().getColumn(3).setPreferredWidth(100);
        tabela.getColumnModel().getColumn(4).setPreferredWidth(70);
        tabela.getColumnModel().getColumn(5).setPreferredWidth(70);
        tabela.getColumnModel().getColumn(6).setPreferredWidth(140);

        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        // Adiciona ao frame
        add(painelFormulario, BorderLayout.WEST);
        add(scrollTabela, BorderLayout.CENTER);

        painelFormulario.setPreferredSize(new Dimension(440, getHeight()));

        // Eventos dos botões
        btnSalvar.addActionListener(e -> salvarDocumento());
        btnEditar.addActionListener(e -> editarDocumento());
        btnExcluir.addActionListener(e -> excluirDocumento());
        btnLimpar.addActionListener(e -> limparCampos());

        // Preencher campos ao clicar na tabela
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtIdDocumento.setText(modelo.getValueAt(linha, 0).toString());
                    txtNomeArquivo.setText(modelo.getValueAt(linha, 1).toString());
                    txtCaminhoArquivo.setText(modelo.getValueAt(linha, 2).toString());
                    txtTipoDocumento.setText(modelo.getValueAt(linha, 3).toString());
                    txtIdProjeto.setText(modelo.getValueAt(linha, 4) != null ? modelo.getValueAt(linha, 4).toString() : "");
                    txtIdUsuario.setText(modelo.getValueAt(linha, 5) != null ? modelo.getValueAt(linha, 5).toString() : "");
                    txtDataUpload.setText(modelo.getValueAt(linha, 6).toString());
                }
            }
        });
    }

    private void estilizarBotaoLinhaEmbaixo(JButton btn) {
        btn.setBackground(Color.WHITE);
        btn.setOpaque(true);
        btn.setForeground(Color.BLACK);
        btn.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY)); // borda cinza só embaixo
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void listarDocumentos() {
        modelo.setRowCount(0);
        List<DocumentoDTO> lista = dao.listarDocumentos();
        for (DocumentoDTO d : lista) {
            modelo.addRow(new Object[]{
                    d.getIdDocumento(),
                    d.getNomeArquivo(),
                    d.getCaminhoArquivo(),
                    d.getTipoDocumento(),
                    d.getIdProjeto(),
                    d.getIdUsuario(),
                    d.getDataUpload()
            });
        }
    }

    private void salvarDocumento() {
        String nome = txtNomeArquivo.getText().trim();
        String caminho = txtCaminhoArquivo.getText().trim();

        if (nome.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O nome do arquivo é obrigatório.");
            return;
        }

        if (caminho.isEmpty()) {
            JOptionPane.showMessageDialog(this, "O caminho do arquivo é obrigatório.");
            return;
        }

        DocumentoDTO d = new DocumentoDTO();
        d.setNomeArquivo(nome);
        d.setCaminhoArquivo(caminho);
        d.setTipoDocumento(txtTipoDocumento.getText().trim());

        String idProjetoStr = txtIdProjeto.getText().trim();
        if (!idProjetoStr.isEmpty()) {
            try {
                d.setIdProjeto(Integer.parseInt(idProjetoStr));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID Projeto inválido.");
                return;
            }
        } else {
            d.setIdProjeto(null);
        }

        String idUsuarioStr = txtIdUsuario.getText().trim();
        if (!idUsuarioStr.isEmpty()) {
            try {
                d.setIdUsuario(Integer.parseInt(idUsuarioStr));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID Usuário inválido.");
                return;
            }
        } else {
            d.setIdUsuario(null);
        }

        boolean ok;
        if (txtIdDocumento.getText().isEmpty()) {
            ok = dao.inserirDocumento(d);
            if (ok) JOptionPane.showMessageDialog(this, "Documento cadastrado com sucesso!");
        } else {
            try {
                d.setIdDocumento(Integer.parseInt(txtIdDocumento.getText()));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID Documento inválido.");
                return;
            }
            ok = dao.atualizarDocumento(d);
            if (ok) JOptionPane.showMessageDialog(this, "Documento atualizado com sucesso!");
        }

        if (ok) {
            listarDocumentos();
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar documento.");
        }
    }

    private void editarDocumento() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            txtIdDocumento.setText(modelo.getValueAt(linha, 0).toString());
            txtNomeArquivo.setText(modelo.getValueAt(linha, 1).toString());
            txtCaminhoArquivo.setText(modelo.getValueAt(linha, 2).toString());
            txtTipoDocumento.setText(modelo.getValueAt(linha, 3).toString());
            txtIdProjeto.setText(modelo.getValueAt(linha, 4) != null ? modelo.getValueAt(linha, 4).toString() : "");
            txtIdUsuario.setText(modelo.getValueAt(linha, 5) != null ? modelo.getValueAt(linha, 5).toString() : "");
            txtDataUpload.setText(modelo.getValueAt(linha, 6).toString());
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um documento para editar.");
        }
    }

    private void excluirDocumento() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int id = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int conf = JOptionPane.showConfirmDialog(this, "Confirma exclusão do documento?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                boolean ok = dao.excluirDocumento(id);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Documento excluído com sucesso!");
                    listarDocumentos();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir documento.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione um documento para excluir.");
        }
    }

    private void limparCampos() {
        txtIdDocumento.setText("");
        txtNomeArquivo.setText("");
        txtCaminhoArquivo.setText("");
        txtTipoDocumento.setText("");
        txtIdProjeto.setText("");
        txtIdUsuario.setText("");
        txtDataUpload.setText("");
        tabela.clearSelection();
    }
}

package View;

import DAO.DoacaoDAO;
import DTO.DoacaoDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class DoacaoView extends JFrame {

    private JTextField txtIdDoacao;
    private JTextField txtIdDoador;
    private JComboBox<String> cbTipo;
    private JTextField txtValor;
    private JTextArea txtDescricao;
    private JTextField txtData;

    private JTable tabela;
    private DefaultTableModel modelo;

    private DoacaoDAO doacaoDAO;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public DoacaoView() {
        doacaoDAO = new DoacaoDAO();
        initComponents();
        listarDoacoes();
    }

    private void initComponents() {
        setTitle("Gerenciamento de Doações");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Fundo azul claro suave
        getContentPane().setBackground(new Color(173, 216, 230));
        setLayout(new BorderLayout(10, 10));

        // Painel do formulário
        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 0 - ID Doação
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Doação:"), gbc);

        txtIdDoacao = new JTextField(10);
        txtIdDoacao.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdDoacao, gbc);

        // Linha 1 - ID Doador
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Doador:"), gbc);

        txtIdDoador = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdDoador, gbc);

        // Linha 2 - Tipo (combo)
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Tipo:"), gbc);

        cbTipo = new JComboBox<>(new String[]{"financeira", "material"});
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(cbTipo, gbc);

        // Linha 3 - Valor
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Valor:"), gbc);

        txtValor = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtValor, gbc);

        // Linha 4 - Descrição (textarea)
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        painelFormulario.add(new JLabel("Descrição:"), gbc);

        txtDescricao = new JTextArea(4, 20);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.BOTH;
        painelFormulario.add(scrollDesc, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 5 - Data
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Data (yyyy-MM-dd):"), gbc);

        txtData = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtData, gbc);

        // Linha 6 - Botões
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnEditar = new JButton("Editar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");

        // Aplica estilo personalizado
        estilizarBotaoLinhaEmbaixoCinza(btnSalvar);
        estilizarBotaoLinhaEmbaixoCinza(btnEditar);
        estilizarBotaoLinhaEmbaixoCinza(btnExcluir);
        estilizarBotaoLinhaEmbaixoCinza(btnLimpar);

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        painelFormulario.add(painelBotoes, gbc);

        // Painel da tabela
        modelo = new DefaultTableModel(
            new Object[]{"ID", "ID Doador", "Tipo", "Valor", "Descrição", "Data"}, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajustar largura das colunas
        tabela.getColumnModel().getColumn(0).setPreferredWidth(40);  // ID
        tabela.getColumnModel().getColumn(1).setPreferredWidth(70);  // ID Doador
        tabela.getColumnModel().getColumn(2).setPreferredWidth(90);  // Tipo
        tabela.getColumnModel().getColumn(3).setPreferredWidth(70);  // Valor
        tabela.getColumnModel().getColumn(4).setPreferredWidth(180); // Descrição
        tabela.getColumnModel().getColumn(5).setPreferredWidth(90);  // Data

        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        // Adiciona painéis ao frame
        add(painelFormulario, BorderLayout.WEST);
        add(scrollTabela, BorderLayout.CENTER);

        // Define tamanho fixo para formulário
        painelFormulario.setPreferredSize(new Dimension(420, getHeight()));

        // Ações dos botões
        btnSalvar.addActionListener(e -> salvarDoacao());
        btnEditar.addActionListener(e -> editarDoacao());
        btnExcluir.addActionListener(e -> excluirDoacao());
        btnLimpar.addActionListener(e -> limparCampos());

        // Preencher formulário ao clicar na tabela
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtIdDoacao.setText(modelo.getValueAt(linha, 0).toString());
                    txtIdDoador.setText(modelo.getValueAt(linha, 1) != null ? modelo.getValueAt(linha, 1).toString() : "");
                    cbTipo.setSelectedItem(modelo.getValueAt(linha, 2).toString());
                    txtValor.setText(modelo.getValueAt(linha, 3).toString());
                    txtDescricao.setText(modelo.getValueAt(linha, 4).toString());
                    txtData.setText(modelo.getValueAt(linha, 5).toString());
                }
            }
        });
    }

    private void estilizarBotaoLinhaEmbaixoCinza(JButton btn) {
        btn.setBackground(Color.WHITE);       // fundo branco
        btn.setOpaque(true);                  // para mostrar o fundo
        btn.setForeground(Color.GRAY);       // texto cinza
        btn.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY)); // borda cinza só embaixo
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void listarDoacoes() {
        modelo.setRowCount(0);
        List<DoacaoDTO> lista = doacaoDAO.listarDoacoes();
        for (DoacaoDTO d : lista) {
            modelo.addRow(new Object[]{
                d.getIdDoacao(),
                d.getIdDoador(),
                d.getTipo(),
                d.getValor(),
                d.getDescricao(),
                d.getData()
            });
        }
    }

    private void salvarDoacao() {
        try {
            DoacaoDTO doacao = new DoacaoDTO();
            String idDoadorStr = txtIdDoador.getText().trim();
            if (!idDoadorStr.isEmpty()) {
                doacao.setIdDoador(Integer.parseInt(idDoadorStr));
            } else {
                doacao.setIdDoador(null);
            }
            doacao.setTipo((String) cbTipo.getSelectedItem());
            doacao.setValor(new BigDecimal(txtValor.getText().trim()));
            doacao.setDescricao(txtDescricao.getText());
            java.util.Date parsedDate = sdf.parse(txtData.getText().trim());
            doacao.setData(new Date(parsedDate.getTime()));

            boolean ok;
            if (txtIdDoacao.getText().isEmpty()) {
                ok = doacaoDAO.inserirDoacao(doacao);
                if (ok) JOptionPane.showMessageDialog(this, "Doação cadastrada com sucesso!");
            } else {
                doacao.setIdDoacao(Integer.parseInt(txtIdDoacao.getText()));
                ok = doacaoDAO.atualizarDoacao(doacao);
                if (ok) JOptionPane.showMessageDialog(this, "Doação atualizada com sucesso!");
            }

            if (ok) {
                listarDoacoes();
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar doação.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID Doador e Valor devem ser numéricos.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use o formato yyyy-MM-dd.");
        }
    }

    private void editarDoacao() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            txtIdDoacao.setText(modelo.getValueAt(linha, 0).toString());
            txtIdDoador.setText(modelo.getValueAt(linha, 1) != null ? modelo.getValueAt(linha, 1).toString() : "");
            cbTipo.setSelectedItem(modelo.getValueAt(linha, 2).toString());
            txtValor.setText(modelo.getValueAt(linha, 3).toString());
            txtDescricao.setText(modelo.getValueAt(linha, 4).toString());
            txtData.setText(modelo.getValueAt(linha, 5).toString());
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma doação para editar.");
        }
    }

    private void excluirDoacao() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int id = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int conf = JOptionPane.showConfirmDialog(this, "Confirma exclusão da doação?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                boolean ok = doacaoDAO.excluirDoacao(id);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Doação excluída com sucesso!");
                    listarDoacoes();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir doação.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma doação para excluir.");
        }
    }

    private void limparCampos() {
        txtIdDoacao.setText("");
        txtIdDoador.setText("");
        cbTipo.setSelectedIndex(0);
        txtValor.setText("");
        txtDescricao.setText("");
        txtData.setText("");
        tabela.clearSelection();
    }
}

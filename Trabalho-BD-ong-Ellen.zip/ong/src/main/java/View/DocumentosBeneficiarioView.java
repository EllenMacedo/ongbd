package View;

import javax.swing.*;
import java.awt.*;

public class DocumentosBeneficiarioView extends JFrame {

    public DocumentosBeneficiarioView() {
        setTitle("Seus Documentos");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        JLabel lbl = new JLabel("Documentos Recebidos:");
        lbl.setBounds(30, 20, 300, 30);
        add(lbl);

        JTextArea txtDocs = new JTextArea();
        txtDocs.setEditable(false);
        txtDocs.setText("• Comprovante de inscrição\n• Termo de participação\n...");
        JScrollPane scroll = new JScrollPane(txtDocs);
        scroll.setBounds(30, 60, 320, 140);
        add(scroll);

        JButton btnFechar = new JButton("Fechar");
        btnFechar.setBounds(150, 210, 100, 30);

        // Estiliza o botão com fundo branco, borda embaixo cinza e texto preto
        estilizarBotaoLinhaEmbaixo(btnFechar);

        btnFechar.addActionListener(e -> dispose());

        add(btnFechar);
    }

    private void estilizarBotaoLinhaEmbaixo(JButton btn) {
        btn.setBackground(Color.WHITE);
        btn.setOpaque(true);
        btn.setForeground(Color.BLACK);
        btn.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY)); // borda cinza só embaixo
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }
}

package View;

import DAO.UsuarioDAO;
import DTO.UsuarioDTO;

import javax.swing.*;
import java.awt.*;

public class CadastroView extends JFrame {

    private JTextField txtNome, txtEmail;
    private JPasswordField txtSenha;
    private JComboBox<String> comboPerfil;
    private JButton btnCadastrar, btnCancelar;

    public CadastroView() {
        setTitle("Cadastro de Usuário");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Fundo azul claro
        getContentPane().setBackground(new Color(173, 216, 230));

        // Painel central branco com bordas arredondadas
        JPanel painelFormulario = new JPanel();
        painelFormulario.setLayout(null);
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBounds(80, 50, 340, 280);
        painelFormulario.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true));
        painelFormulario.setOpaque(true);

        // Usar um JLayeredPane para sobrepor o painel branco no fundo azul
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(500, 400));
        layeredPane.add(painelFormulario, Integer.valueOf(1));

        // Labels e campos
        JLabel lblNome = new JLabel("Nome:");
        lblNome.setBounds(30, 20, 80, 20);
        painelFormulario.add(lblNome);

        txtNome = new JTextField();
        txtNome.setBounds(110, 20, 180, 25);
        painelFormulario.add(txtNome);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(30, 60, 80, 20);
        painelFormulario.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(110, 60, 180, 25);
        painelFormulario.add(txtEmail);

        JLabel lblSenha = new JLabel("Senha:");
        lblSenha.setBounds(30, 100, 80, 20);
        painelFormulario.add(lblSenha);

        txtSenha = new JPasswordField();
        txtSenha.setBounds(110, 100, 180, 25);
        painelFormulario.add(txtSenha);

        JLabel lblPerfil = new JLabel("Perfil:");
        lblPerfil.setBounds(30, 140, 80, 20);
        painelFormulario.add(lblPerfil);

        comboPerfil = new JComboBox<>(new String[]{" ", "voluntario", "beneficiario", "doador"});
        comboPerfil.setBounds(110, 140, 180, 25);
        painelFormulario.add(comboPerfil);

        btnCadastrar = new JButton("Cadastrar");
        btnCadastrar.setBounds(40, 200, 120, 30);
        estilizarBotaoLinhaEmbaixo(btnCadastrar);
        painelFormulario.add(btnCadastrar);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(180, 200, 120, 30);
        estilizarBotaoLinhaEmbaixo(btnCancelar);
        painelFormulario.add(btnCancelar);

        btnCadastrar.addActionListener(e -> cadastrarUsuario());
        btnCancelar.addActionListener(e -> {
            new EntradaView().setVisible(true);
            this.dispose();
        });

        add(layeredPane, BorderLayout.CENTER);
    }

    private void estilizarBotaoLinhaEmbaixo(JButton btn) {
        btn.setContentAreaFilled(false); // fundo transparente
        btn.setOpaque(false);
        btn.setForeground(Color.BLACK);
        btn.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY)); // borda só embaixo
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void cadastrarUsuario() {
        String nome = txtNome.getText().trim();
        String email = txtEmail.getText().trim();
        String senha = new String(txtSenha.getPassword());
        String perfil = (String) comboPerfil.getSelectedItem();

        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!");
            return;
        }

        UsuarioDTO usuario = new UsuarioDTO();
        usuario.setNome(nome);
        usuario.setEmail(email);
        usuario.setSenha(senha);
        usuario.setPerfil(perfil);
        usuario.setAtivo(true);

        UsuarioDAO dao = new UsuarioDAO();
        boolean sucesso = dao.inserirUsuario(usuario);

        if (sucesso) {
            JOptionPane.showMessageDialog(this, "Usuário cadastrado com sucesso!");
            new EntradaView().setVisible(true);
            this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao cadastrar usuário.");
        }
    }
}

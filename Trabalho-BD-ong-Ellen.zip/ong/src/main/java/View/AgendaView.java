package View;

import DAO.AgendaDAO;
import DTO.AgendaDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.awt.*;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class AgendaView extends JFrame {

    private JTextField txtIdAgenda;
    private JTextField txtIdUsuario;
    private JTextField txtTitulo;
    private JTextArea txtDescricao;
    private JTextField txtDataInicio;
    private JTextField txtDataFim;
    private JTextField txtLocal;

    private JTable tabela;
    private DefaultTableModel modelo;

    private AgendaDAO dao;

    private SimpleDateFormat formatoDataHora = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public AgendaView() {
        dao = new AgendaDAO();
        initComponents();
        listarAgenda();
    }

    private void initComponents() {
        setTitle("Gerenciamento de Agenda");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new java.awt.Color(173, 216, 230)); // Azul claro


        JLabel lblIdAgenda = new JLabel("ID Agenda:");
        lblIdAgenda.setBounds(10, 10, 80, 25);
        add(lblIdAgenda);

        txtIdAgenda = new JTextField();
        txtIdAgenda.setBounds(100, 10, 80, 25);
        txtIdAgenda.setEditable(false);
        add(txtIdAgenda);

        JLabel lblIdUsuario = new JLabel("ID Usuário:");
        lblIdUsuario.setBounds(10, 45, 80, 25);
        add(lblIdUsuario);

        txtIdUsuario = new JTextField();
        txtIdUsuario.setBounds(100, 45, 80, 25);
        add(txtIdUsuario);

        JLabel lblTitulo = new JLabel("Título:");
        lblTitulo.setBounds(10, 80, 80, 25);
        add(lblTitulo);

        txtTitulo = new JTextField();
        txtTitulo.setBounds(100, 80, 200, 25);
        add(txtTitulo);

        JLabel lblDescricao = new JLabel("Descrição:");
        lblDescricao.setBounds(10, 115, 80, 25);
        add(lblDescricao);

        txtDescricao = new JTextArea();
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDescricao = new JScrollPane(txtDescricao);
        scrollDescricao.setBounds(100, 115, 300, 80);
        add(scrollDescricao);

        JLabel lblDataInicio = new JLabel("Data Início (yyyy-MM-dd HH:mm:ss):");
        lblDataInicio.setBounds(10, 205, 250, 25);
        add(lblDataInicio);

        txtDataInicio = new JTextField();
        txtDataInicio.setBounds(260, 205, 140, 25);
        add(txtDataInicio);

        JLabel lblDataFim = new JLabel("Data Fim (yyyy-MM-dd HH:mm:ss):");
        lblDataFim.setBounds(10, 240, 250, 25);
        add(lblDataFim);

        txtDataFim = new JTextField();
        txtDataFim.setBounds(260, 240, 140, 25);
        add(txtDataFim);

        JLabel lblLocal = new JLabel("Local:");
        lblLocal.setBounds(10, 275, 80, 25);
        add(lblLocal);

        txtLocal = new JTextField();
        txtLocal.setBounds(100, 275, 300, 25);
        add(txtLocal);

        JButton btnSalvar = new JButton("Salvar");
        btnSalvar.setBounds(10, 310, 100, 30);
        estilizarBotaoLinhaEmbaixo(btnSalvar);
        add(btnSalvar);

        JButton btnExcluir = new JButton("Excluir");
        btnExcluir.setBounds(120, 310, 100, 30);
        estilizarBotaoLinhaEmbaixo(btnExcluir);
        add(btnExcluir);

        JButton btnLimpar = new JButton("Limpar");
        btnLimpar.setBounds(230, 310, 100, 30);
        estilizarBotaoLinhaEmbaixo(btnLimpar);
        add(btnLimpar);

        modelo = new DefaultTableModel(new Object[]{"ID", "ID Usuário", "Título", "Descrição", "Data Início", "Data Fim", "Local"}, 0);
        tabela = new JTable(modelo);
        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBounds(420, 10, 460, 540);
        add(scrollTabela);

        btnSalvar.addActionListener(e -> salvarAgenda());
        btnExcluir.addActionListener(e -> excluirAgenda());
        btnLimpar.addActionListener(e -> limparCampos());

        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtIdAgenda.setText(modelo.getValueAt(linha, 0).toString());
                    txtIdUsuario.setText(modelo.getValueAt(linha, 1).toString());
                    txtTitulo.setText(modelo.getValueAt(linha, 2).toString());
                    txtDescricao.setText(modelo.getValueAt(linha, 3).toString());
                    txtDataInicio.setText(modelo.getValueAt(linha, 4).toString());
                    txtDataFim.setText(modelo.getValueAt(linha, 5) != null ? modelo.getValueAt(linha, 5).toString() : "");
                    txtLocal.setText(modelo.getValueAt(linha, 6).toString());
                }
            }
        });
    }

    private void estilizarBotaoLinhaEmbaixo(JButton btn) {
    btn.setBackground(Color.WHITE);      // fundo branco
    btn.setOpaque(true);                 // para fundo ser visível
    btn.setForeground(Color.BLACK);      // texto preto
    btn.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY)); // somente linha embaixo
    btn.setFocusPainted(false);
    btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
}


    private void listarAgenda() {
        modelo.setRowCount(0);
        List<AgendaDTO> lista = dao.listarAgenda();
        for (AgendaDTO a : lista) {
            modelo.addRow(new Object[]{
                    a.getIdAgenda(),
                    a.getIdUsuario(),
                    a.getTitulo(),
                    a.getDescricao(),
                    a.getDataInicio(),
                    a.getDataFim(),
                    a.getLocal()
            });
        }
    }

    private void salvarAgenda() {
        String idUsuarioStr = txtIdUsuario.getText().trim();
        String titulo = txtTitulo.getText().trim();
        String descricao = txtDescricao.getText().trim();
        String dataInicioStr = txtDataInicio.getText().trim();
        String dataFimStr = txtDataFim.getText().trim();
        String local = txtLocal.getText().trim();

        if (idUsuarioStr.isEmpty() || titulo.isEmpty() || dataInicioStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe pelo menos ID do usuário, título e data de início.");
            return;
        }

        int idUsuario;
        try {
            idUsuario = Integer.parseInt(idUsuarioStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID do usuário inválido.");
            return;
        }

        Timestamp dataInicio;
        Timestamp dataFim = null;
        try {
            dataInicio = new Timestamp(formatoDataHora.parse(dataInicioStr).getTime());
            if (!dataFimStr.isEmpty()) {
                dataFim = new Timestamp(formatoDataHora.parse(dataFimStr).getTime());
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use o formato yyyy-MM-dd HH:mm:ss");
            return;
        }

        AgendaDTO agenda = new AgendaDTO();
        agenda.setIdUsuario(idUsuario);
        agenda.setTitulo(titulo);
        agenda.setDescricao(descricao);
        agenda.setDataInicio(dataInicio);
        agenda.setDataFim(dataFim);
        agenda.setLocal(local);

        String idAgendaStr = txtIdAgenda.getText().trim();
        boolean sucesso;
        if (idAgendaStr.isEmpty()) {
            sucesso = dao.inserirAgenda(agenda);
        } else {
            try {
                agenda.setIdAgenda(Integer.parseInt(idAgendaStr));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID da agenda inválido.");
                return;
            }
            sucesso = dao.atualizarAgenda(agenda);
        }

        if (sucesso) {
            JOptionPane.showMessageDialog(this, "Agenda salva com sucesso!");
            listarAgenda();
            limparCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Erro ao salvar agenda.");
        }
    }

    private void excluirAgenda() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int idAgenda = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int resp = JOptionPane.showConfirmDialog(this, "Confirma exclusão da agenda?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (resp == JOptionPane.YES_OPTION) {
                boolean ok = dao.excluirAgenda(idAgenda);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Agenda excluída com sucesso!");
                    listarAgenda();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir agenda.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma agenda para excluir.");
        }
    }

    private void limparCampos() {
        txtIdAgenda.setText("");
        txtIdUsuario.setText("");
        txtTitulo.setText("");
        txtDescricao.setText("");
        txtDataInicio.setText("");
        txtDataFim.setText("");
        txtLocal.setText("");
        tabela.clearSelection();
    }
}

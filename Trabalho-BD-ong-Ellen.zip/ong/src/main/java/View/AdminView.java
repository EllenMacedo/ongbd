package View;

import javax.swing.*;
import java.awt.*;

public class AdminView extends JFrame {

    public AdminView() {
        // Tela cheia
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Painel do Administrador");

        // Painel principal com fundo bege claro
        JPanel painelPrincipal = new JPanel(new BorderLayout());
        painelPrincipal.setBackground(new Color(245, 245, 220)); // bege claro

        // Painel lateral verde claro (menu com botões)
        JPanel painelLateral = new JPanel();
        painelLateral.setPreferredSize(new Dimension(250, getHeight()));
        painelLateral.setBackground(new Color(144, 238, 144)); // verde claro
        painelLateral.setLayout(null);

        // Label da logo no topo
        JLabel lblLogo = new JLabel("ONG", SwingConstants.CENTER);
        lblLogo.setFont(new Font("Arial", Font.BOLD, 20));
        lblLogo.setForeground(Color.DARK_GRAY);
        lblLogo.setBounds(0, 20, 250, 40);
        painelLateral.add(lblLogo);

        // Botões na barra lateral (removido "Gerenciar Relatórios")
        String[] btnTexts = {
            "Gerenciar Usuários", "Gerenciar Projetos", "Gerenciar Eventos",
            "Gerenciar Doações", "Gerenciar Recursos",
            "Gerenciar Documentos", "Gerenciar Feedback", "Gerenciar Agenda", "Logout"
        };

        JButton[] botoes = new JButton[btnTexts.length];
        int y = 80;
        for (int i = 0; i < btnTexts.length; i++) {
            JButton btn = new JButton(btnTexts[i]);
            btn.setBounds(15, y, 220, 35);
            btn.setBackground(Color.WHITE);
            btn.setForeground(Color.BLACK);
            btn.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.BLACK));
            btn.setFocusPainted(false);
            painelLateral.add(btn);
            botoes[i] = btn;
            y += 45;
        }

        // Área principal branca arredondada (vazia por enquanto)
        JPanel painelConteudo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
            }
        };
        painelConteudo.setOpaque(false);
        painelConteudo.setLayout(new BorderLayout());

        // Texto de boas-vindas centralizado na área principal
        JLabel lblBoasVindas = new JLabel("Bem-vindo, Administrador!", SwingConstants.CENTER);
        lblBoasVindas.setFont(new Font("Arial", Font.BOLD, 24));
        painelConteudo.add(lblBoasVindas, BorderLayout.CENTER);

        // Painel central para conter o painelConteudo com padding
        JPanel painelCentro = new JPanel(new GridBagLayout());
        painelCentro.setOpaque(false);
        painelCentro.add(painelConteudo, new GridBagConstraints());

        painelPrincipal.add(painelLateral, BorderLayout.WEST);
        painelPrincipal.add(painelCentro, BorderLayout.CENTER);

        add(painelPrincipal);

        // Ações dos botões para abrir as janelas correspondentes (ajustado índice)
        botoes[0].addActionListener(e -> new GerenciamentoUsuarioView().setVisible(true));
        botoes[1].addActionListener(e -> new ProjetoView().setVisible(true));
        botoes[2].addActionListener(e -> new EventoView().setVisible(true));
        botoes[3].addActionListener(e -> new DoacaoView().setVisible(true));
        botoes[4].addActionListener(e -> new SaidaView().setVisible(true));
        botoes[5].addActionListener(e -> new DocumentoView().setVisible(true));
        botoes[6].addActionListener(e -> new FeedbackView().setVisible(true));
        botoes[7].addActionListener(e -> new AgendaView().setVisible(true));
        botoes[8].addActionListener(e -> {
            dispose();
            new EntradaView().setVisible(true);
        });

        setVisible(true);
    }
}

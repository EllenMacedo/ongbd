package View;

import DAO.SaidaDAO;
import DTO.SaidaDTO;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

public class SaidaView extends JFrame {

    private JTextField txtIdSaida;
    private JTextField txtIdDoacao;
    private JTextField txtIdDoador;
    private JComboBox<String> cbTipo;
    private JTextField txtValor;
    private JTextArea txtDescricao;
    private JTextField txtData;
    private JTextField txtProjetoId;

    private JTable tabela;
    private DefaultTableModel modelo;

    private SaidaDAO saidaDAO;
    private final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public SaidaView() {
        saidaDAO = new SaidaDAO();
        initComponents();
        listarSaidas();
    }

    private void initComponents() {
        setTitle("Gerenciamento de Saídas");
        setSize(950, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Fundo azul claro suave
        getContentPane().setBackground(new Color(173, 216, 230));
        setLayout(new BorderLayout(10, 10));

        // Painel do formulário
        JPanel painelFormulario = new JPanel(new GridBagLayout());
        painelFormulario.setBackground(Color.WHITE);
        painelFormulario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 0 - ID Saída (não editável)
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Saída:"), gbc);

        txtIdSaida = new JTextField(10);
        txtIdSaida.setEditable(false);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdSaida, gbc);

        // Linha 1 - ID Doação
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Doação:"), gbc);

        txtIdDoacao = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdDoacao, gbc);

        // Linha 2 - ID Doador
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Doador:"), gbc);

        txtIdDoador = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtIdDoador, gbc);

        // Linha 3 - Tipo (combo: entrada, saida)
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Tipo:"), gbc);

        cbTipo = new JComboBox<>(new String[]{"entrada", "saida"});
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(cbTipo, gbc);

        // Linha 4 - Valor
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Valor:"), gbc);

        txtValor = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtValor, gbc);

        // Linha 5 - Descrição (textarea)
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        painelFormulario.add(new JLabel("Descrição:"), gbc);

        txtDescricao = new JTextArea(4, 20);
        txtDescricao.setLineWrap(true);
        txtDescricao.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDescricao);
        gbc.gridx = 1; gbc.weightx = 1; gbc.fill = GridBagConstraints.BOTH;
        painelFormulario.add(scrollDesc, gbc);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Linha 6 - Data
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("Data (yyyy-MM-dd):"), gbc);

        txtData = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtData, gbc);

        // Linha 7 - Projeto ID (opcional)
        gbc.gridx = 0; gbc.gridy++;
        gbc.weightx = 0;
        painelFormulario.add(new JLabel("ID Projeto (opcional):"), gbc);

        txtProjetoId = new JTextField(15);
        gbc.gridx = 1; gbc.weightx = 1;
        painelFormulario.add(txtProjetoId, gbc);

        // Linha 8 - Botões
        gbc.gridx = 0; gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        painelBotoes.setBackground(Color.WHITE);

        JButton btnSalvar = new JButton("Salvar");
        JButton btnEditar = new JButton("Editar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");

        estilizarBotaoLinhaEmbaixo(btnSalvar);
        estilizarBotaoLinhaEmbaixo(btnEditar);
        estilizarBotaoLinhaEmbaixo(btnExcluir);
        estilizarBotaoLinhaEmbaixo(btnLimpar);

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);

        painelFormulario.add(painelBotoes, gbc);

        // Painel da tabela
        modelo = new DefaultTableModel(
            new Object[]{"ID Saída", "ID Doação", "ID Doador", "Tipo", "Valor", "Descrição", "Data", "ID Projeto"}, 0);
        tabela = new JTable(modelo);
        tabela.setRowHeight(24);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        // Ajustar largura das colunas
        tabela.getColumnModel().getColumn(0).setPreferredWidth(60);  // ID Saída
        tabela.getColumnModel().getColumn(1).setPreferredWidth(70);  // ID Doação
        tabela.getColumnModel().getColumn(2).setPreferredWidth(70);  // ID Doador
        tabela.getColumnModel().getColumn(3).setPreferredWidth(70);  // Tipo
        tabela.getColumnModel().getColumn(4).setPreferredWidth(80);  // Valor
        tabela.getColumnModel().getColumn(5).setPreferredWidth(220); // Descrição
        tabela.getColumnModel().getColumn(6).setPreferredWidth(90);  // Data
        tabela.getColumnModel().getColumn(7).setPreferredWidth(70);  // Projeto ID

        JScrollPane scrollTabela = new JScrollPane(tabela);
        scrollTabela.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 180), 1, true),
                new EmptyBorder(10, 10, 10, 10)
        ));

        // Adiciona painéis ao frame
        add(painelFormulario, BorderLayout.WEST);
        add(scrollTabela, BorderLayout.CENTER);

        // Define tamanho fixo para formulário
        painelFormulario.setPreferredSize(new Dimension(450, getHeight()));

        // Ações dos botões
        btnSalvar.addActionListener(e -> salvarSaida());
        btnEditar.addActionListener(e -> editarSaida());
        btnExcluir.addActionListener(e -> excluirSaida());
        btnLimpar.addActionListener(e -> limparCampos());

        // Preencher formulário ao clicar na tabela
        tabela.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int linha = tabela.getSelectedRow();
                if (linha >= 0) {
                    txtIdSaida.setText(modelo.getValueAt(linha, 0).toString());
                    txtIdDoacao.setText(modelo.getValueAt(linha, 1).toString());
                    txtIdDoador.setText(modelo.getValueAt(linha, 2).toString());
                    cbTipo.setSelectedItem(modelo.getValueAt(linha, 3).toString());
                    txtValor.setText(modelo.getValueAt(linha, 4).toString());
                    txtDescricao.setText(modelo.getValueAt(linha, 5).toString());
                    txtData.setText(modelo.getValueAt(linha, 6).toString());
                    txtProjetoId.setText(modelo.getValueAt(linha, 7) != null ? modelo.getValueAt(linha, 7).toString() : "");
                }
            }
        });
    }

    private void estilizarBotaoLinhaEmbaixo(JButton btn) {
        btn.setContentAreaFilled(false); // fundo transparente
        btn.setOpaque(false);
        btn.setForeground(Color.BLACK);
        btn.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.GRAY)); // borda só embaixo
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void listarSaidas() {
        modelo.setRowCount(0);
        List<SaidaDTO> lista = saidaDAO.listarSaidas();
        for (SaidaDTO s : lista) {
            modelo.addRow(new Object[]{
                s.getIdSaida(),
                s.getIdDoacao(),
                s.getIdDoador(),
                s.getTipo(),
                s.getValor(),
                s.getDescricao(),
                s.getData(),
                s.getProjetoId()
            });
        }
    }

    private void salvarSaida() {
        try {
            SaidaDTO saida = new SaidaDTO();

            String idDoacaoStr = txtIdDoacao.getText().trim();
            String idDoadorStr = txtIdDoador.getText().trim();
            String projetoIdStr = txtProjetoId.getText().trim();

            if (idDoacaoStr.isEmpty() || idDoadorStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "ID Doação e ID Doador são obrigatórios.");
                return;
            }

            saida.setIdDoacao(Integer.parseInt(idDoacaoStr));
            saida.setIdDoador(Integer.parseInt(idDoadorStr));
            saida.setTipo((String) cbTipo.getSelectedItem());
            saida.setValor(new BigDecimal(txtValor.getText().trim()));
            saida.setDescricao(txtDescricao.getText());

            java.util.Date parsedDate = sdf.parse(txtData.getText().trim());
            saida.setData(new Date(parsedDate.getTime()));

            if (!projetoIdStr.isEmpty())
                saida.setProjetoId(Integer.parseInt(projetoIdStr));
            else
                saida.setProjetoId(null);

            boolean ok;
            if (txtIdSaida.getText().isEmpty()) {
                ok = saidaDAO.inserirSaida(saida);
                if (ok) JOptionPane.showMessageDialog(this, "Saída cadastrada com sucesso!");
            } else {
                saida.setIdSaida(Integer.parseInt(txtIdSaida.getText()));
                ok = saidaDAO.atualizarSaida(saida);
                if (ok) JOptionPane.showMessageDialog(this, "Saída atualizada com sucesso!");
            }

            if (ok) {
                listarSaidas();
                limparCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Erro ao salvar saída.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "IDs e Valor devem ser numéricos.");
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use o formato yyyy-MM-dd.");
        }
    }

    private void editarSaida() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            txtIdSaida.setText(modelo.getValueAt(linha, 0).toString());
            txtIdDoacao.setText(modelo.getValueAt(linha, 1).toString());
            txtIdDoador.setText(modelo.getValueAt(linha, 2).toString());
            cbTipo.setSelectedItem(modelo.getValueAt(linha, 3).toString());
            txtValor.setText(modelo.getValueAt(linha, 4).toString());
            txtDescricao.setText(modelo.getValueAt(linha, 5).toString());
            txtData.setText(modelo.getValueAt(linha, 6).toString());
            txtProjetoId.setText(modelo.getValueAt(linha, 7) != null ? modelo.getValueAt(linha, 7).toString() : "");
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma saída para editar.");
        }
    }

    private void excluirSaida() {
        int linha = tabela.getSelectedRow();
        if (linha >= 0) {
            int idSaida = Integer.parseInt(modelo.getValueAt(linha, 0).toString());
            int idDoacao = Integer.parseInt(modelo.getValueAt(linha, 1).toString());
            int idDoador = Integer.parseInt(modelo.getValueAt(linha, 2).toString());

            int conf = JOptionPane.showConfirmDialog(this, "Confirma exclusão da saída?", "Excluir", JOptionPane.YES_NO_OPTION);
            if (conf == JOptionPane.YES_OPTION) {
                boolean ok = saidaDAO.excluirSaida(idSaida, idDoacao, idDoador);
                if (ok) {
                    JOptionPane.showMessageDialog(this, "Saída excluída com sucesso!");
                    listarSaidas();
                    limparCampos();
                } else {
                    JOptionPane.showMessageDialog(this, "Erro ao excluir saída.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma saída para excluir.");
        }
    }

    private void limparCampos() {
        txtIdSaida.setText("");
        txtIdDoacao.setText("");
        txtIdDoador.setText("");
        cbTipo.setSelectedIndex(0);
        txtValor.setText("");
        txtDescricao.setText("");
        txtData.setText("");
        txtProjetoId.setText("");
        tabela.clearSelection();
    }
}
